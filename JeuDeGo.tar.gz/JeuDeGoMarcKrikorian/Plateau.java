import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;
import javax.swing.Timer;

public class Plateau extends JPanel implements MouseListener,MouseMotionListener,ActionListener,ListSelectionListener {

	int taille;
	int cote;
	int player;
	int[][] tab = null;
	int[][] tabf = null;
	boolean[][] verif = null;
	int a;
	double t;
	int handi;
	HorSco sco;
	boolean terminer = false;
	int winner =0;
	Historique histo;
	int tour = 0;
	JButton valider = new JButton("Valider");
	JButton retour = new JButton("Retour au jeu");
	JLabel indic = new JLabel("Groupes morts : Click gauche --> ajouter, Click droite --> retirer");
	JButton ok = new JButton("OK");
	JLabel gagnant = new JLabel();
	JLabel vict = new JLabel();
	Boolean abandon = false;
	double scoruf=0;
	double scordf=0;
	Timer time = null;


	Plateau(int taille,HorSco sco,int handi,Historique histo){
		this.taille = taille;
		this.cote = 800/taille;
		this.tab = new int[taille][taille];
		this.tabf = new int[taille][taille];
		this.verif = new boolean[taille][taille];
		this.player = 2;
		this.t = cote/1.4;
		this.sco=sco;
		this.handi=handi;
		this.histo=histo;
		if(sco.type==2) time = new Timer(1000,this);
		this.sco.passe.addActionListener(this);
		this.sco.aban.addActionListener(this);
		this.histo.scroll.addListSelectionListener(this);
		this.valider.addActionListener(this);
		this.retour.addActionListener(this);

		addMouseListener(this);
		addMouseMotionListener(this);

		int y;
		for(int i=0;i<taille;i=i+1){
			for(y=0;y<taille;y=y+1){
				tab[i][y]=0;
				tabf[i][y]=0;
				verif[i][y]=false;
			}
			y=0;
		}
		setSize(850,900);
		setLocation(0,0);

		if(this.handi == 0){
			this.sco.bonus = 7.5;
			this.player=1;
			this.sco.player=1;
		}
		else {
			this.sco.player=2;
			if(taille == 19){
				if(handi == 1)tab[9][9]=1;
				else if(handi ==2){
					tab[15][3]=1;
					tab[3][15]=1;
				}
				else if(handi == 3){
					tab[15][3]=1;
					tab[3][15]=1;
					tab[9][9]=1;
				}
				else if(handi == 4){
					tab[15][3]=1;
					tab[3][15]=1;
					tab[3][3]=1;
					tab[15][15]=1;
				}
				else if(handi == 5){
					tab[15][3]=1;
					tab[3][15]=1;
					tab[3][3]=1;
					tab[15][15]=1;
					tab[9][9]=1;
				}
				else if(handi == 6){
					tab[15][3]=1;
					tab[3][15]=1;
					tab[3][3]=1;
					tab[15][15]=1;
					tab[9][3]=1;
					tab[9][15]=1;
				}
				else if(handi == 7){
					tab[15][3]=1;
					tab[3][15]=1;
					tab[3][3]=1;
					tab[15][15]=1;
					tab[9][3]=1;
					tab[9][15]=1;
					tab[9][9]=1;
				}
				else if(handi ==8){
					tab[15][3]=1;
					tab[3][15]=1;
					tab[3][3]=1;
					tab[15][15]=1;
					tab[9][3]=1;
					tab[9][15]=1;
					tab[3][9]=1;
					tab[15][9]=1;
				}
				else {
					tab[15][3]=1;
					tab[3][15]=1;
					tab[3][3]=1;
					tab[15][15]=1;
					tab[9][3]=1;
					tab[9][15]=1;
					tab[3][9]=1;
					tab[15][9]=1;
					tab[9][9]=1;
				}
			}
			else if(taille == 13){
				if(handi==1) tab[6][6]=1;
				else if(handi==2){
					tab[9][3]=1;
					tab[3][9]=1;
				}
				else if(handi==3){
					tab[9][3]=1;
					tab[3][9]=1;
					tab[6][6]=1;
				}
				else if(handi==4){
					tab[9][3]=1;
					tab[3][3]=1;
					tab[9][9]=1;
					tab[3][9]=1;
				}
				else {
					tab[9][3]=1;
					tab[3][3]=1;
					tab[9][9]=1;
					tab[3][9]=1;
					tab[6][6]=1;
				}
			}
			else{
				if(handi==1) tab[4][4]=1;
				else if(handi==2){
					tab[2][6]=1;
					tab[6][2]=1;
				}
				else if(handi==3){
					tab[6][2]=1;
					tab[2][6]=1;
					tab[4][4]=1;
				}
				else if(handi==4){
					tab[6][2]=1;
					tab[2][2]=1;
					tab[6][6]=1;
					tab[2][6]=1;
				}
				else {
					tab[6][2]=1;
					tab[2][2]=1;
					tab[6][6]=1;
					tab[2][6]=1;
					tab[4][4]=1;
				}
			}
		}

		int[][] tabt = new int[taille][taille];

		for(int i=0;i<taille;i++){
			for(int j=0;j<taille;j++){
				tabt[i][j]=tab[i][j];
			}
		}

		Save start = new Save(tabt,player,sco.scoreu,sco.scored,tour);
		histo.hi.addElement(start);
		histo.scroll.setSelectedIndex(tour);
		tour = tour +1;
		if(sco.type==2)time.start();
	}

	@Override
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	int y = 0;
    	int i = 0;

    	g.setColor(new Color(222,184,135));
    	g.fillRect(0,0,850,900);

    	for(;i<taille;i=i+1){
			for(;y<taille;y=y+1){
				if(i!=taille-1 && y!=taille-1) {

					g.setColor(Color.BLACK);
					g.drawRect(i*cote+40+cote/4,y*cote+50+cote/4,cote,cote);
				}

				if(taille==19){
					if((i==3 && y==3) || (i==9 && y==3) ||(i==15 && y==3) || (i==3 && y==9) || (i==9 && y==9) || (i==15 && y==9) || (i==3 && y==15) || (i==9 && y==15) || (i==15 && y==15)){
						g.fillOval(i*cote+47,y*cote+57,cote/6,cote/6);
					}

					if(tab[i][y]==1){
						g.setColor(Color.BLACK);
						g.fillOval(i*cote+35,y*cote+46,(int)t,(int)t);
					}

					if(tab[i][y]==2){
						g.setColor(Color.WHITE);
						g.fillOval(i*cote+35,y*cote+46,(int)t,(int)t);
						g.setColor(Color.BLACK);
					}

					if(tabf[i][y]==1){
						g.setColor(Color.BLACK);
						g.fillOval(i*cote+35,y*cote+46,(int)t/2,(int)t/2);
					}

					if(tabf[i][y]==2){
						g.setColor(Color.WHITE);
						g.fillOval(i*cote+35,y*cote+46,(int)t/2,(int)t/2);
						g.setColor(Color.BLACK);
					}

					if(tab[i][y]==3){
						g.setColor(Color.BLACK);
						g.drawOval(i*cote+35,y*cote+46,(int)t,(int)t);
					}
					if(tab[i][y]==4){
						g.setColor(Color.WHITE);
						g.drawOval(i*cote+35,y*cote+46,(int)t,(int)t);
						g.setColor(Color.BLACK);
					}
				}
				
				else if(taille==13){
					if((i==3 && y==3) || (i==9 && y==3) ||(i==3 && y==9) || (i==9 && y==9) || (i==6 && y==6)){
						g.fillOval(i*cote+52,y*cote+62,cote/8,cote/8);
					}

					if(tab[i][y]==1){
						g.setColor(Color.BLACK);
						g.fillOval(i*cote+34,y*cote+43,(int)t,(int)t);
					}

					if(tab[i][y]==2){
						g.setColor(Color.WHITE);
						g.fillOval(i*cote+34,y*cote+43,(int)t,(int)t);
						g.setColor(Color.BLACK);
					}

					if(tabf[i][y]==1){
						g.setColor(Color.BLACK);
						g.fillOval(i*cote+34,y*cote+43,(int)t/2,(int)t/2);
					}

					if(tabf[i][y]==2){
						g.setColor(Color.WHITE);
						g.fillOval(i*cote+34,y*cote+43,(int)t/2,(int)t/2);
						g.setColor(Color.BLACK);
					}

					if(tab[i][y]==3){
						g.setColor(Color.BLACK);
						g.drawOval(i*cote+34,y*cote+43,(int)t,(int)t);
					}
					if(tab[i][y]==4){
						g.setColor(Color.WHITE);
						g.drawOval(i*cote+34,y*cote+43,(int)t,(int)t);
						g.setColor(Color.BLACK);
					}
				}
				else{
					if((i==2 && y==2) || (i==6 && y==2) ||(i==2 && y==6) || (i==6 && y==6) || (i==4 && y==4)){
						g.fillOval(i*cote+58,y*cote+67,cote/10,cote/10);
					}

					if(tab[i][y]==1){
						g.setColor(Color.BLACK);
						g.fillOval(i*cote+32,y*cote+42,(int)t,(int)t);
					}

					if(tab[i][y]==2){
						g.setColor(Color.WHITE);
						g.fillOval(i*cote+32,y*cote+42,(int)t,(int)t);
						g.setColor(Color.BLACK);
					}

					if(tabf[i][y]==1){
						g.setColor(Color.BLACK);
						g.fillOval(i*cote+32,y*cote+42,(int)t/2,(int)t/2);
					}

					if(tabf[i][y]==2){
						g.setColor(Color.WHITE);
						g.fillOval(i*cote+32,y*cote+42,(int)t/2,(int)t/2);
						g.setColor(Color.BLACK);
					}

					if(tab[i][y]==3){
						g.setColor(Color.BLACK);
						g.drawOval(i*cote+32,y*cote+42,(int)t,(int)t);
					}
					
					if(tab[i][y]==4){
						g.setColor(Color.WHITE);
						g.drawOval(i*cote+32,y*cote+42,(int)t,(int)t);
						g.setColor(Color.BLACK);
					}
				}

			}
			y=0;
		}

		if(terminer==true && winner==0){
			this.add(valider);
			valider.setLocation(500,820);
			valider.setSize(130,25);
			this.add(retour);
			retour.setLocation(200,820);
			this.add(indic);
			indic.setLocation(230,10);

		}
		else {
			this.remove(valider);
			this.remove(retour);
			this.remove(indic);
		}

		if(winner!=0){

			g.setColor(Color.WHITE);
			g.fillRect(150,225,600,300);
			g.setColor(Color.BLACK);

			this.add(gagnant);
			this.add(vict);
			this.add(ok);
			
			if(winner==1)gagnant.setText("Joueur 1 gagne");
			else if(winner==2)gagnant.setText("Joueur 2 gagne");
			else gagnant.setText("Egalité");

			if(winner!=3)gagnant.setLocation(250,240);
			else gagnant.setLocation(350,240);
			gagnant.setFont(new Font("Arial",Font.BOLD,50));

			if(abandon==true && winner==1) vict.setText("Abandon du Joueur 2");
			else if(abandon==true && winner==2) vict.setText("Abandon du Joueur 1");
			else vict.setText("Score J1-J2: "+scoruf+" - "+scordf+"");

			vict.setLocation(290,350);
			vict.setFont(new Font("Arial",Font.BOLD,25));

			ok.setLocation(405,450);
			ok.setSize(100,50);
		}

    }

    Boolean verification(int x,int y,int player,int[][] tabl,boolean[][] verif){

    	boolean res;

    	
	    if((x!=0 && tabl[x-1][y]==0) || (x!=taille-1 && tabl[x+1][y]==0) || (y!=taille-1 && tabl[x][y+1]==0) || (y!=0 && tabl[x][y-1]==0)){
	    	return false;
	    }
	   	if(x!=0 && tabl[x-1][y]==player && verif[x-1][y]==false){
	   		verif[x][y]=true;
	   		res=verification(x-1,y,player,tabl,verif);
	   		if(res==false) return false;
	   	}
	   	if(x!=taille-1 && tabl[x+1][y]==player && verif[x+1][y]==false){
	   		verif[x][y]=true;
	   		res=verification(x+1,y,player,tabl,verif);
	   		if(res==false) return false;
	   	}
	   	if(y!=taille-1 && tabl[x][y+1]==player && verif[x][y+1]==false){
	   		verif[x][y]=true;
	   		res=verification(x,y+1,player,tabl,verif);
	   		if(res==false) return false;
	   	}
	   	if(y!=0 && tabl[x][y-1]==player && verif[x][y-1]==false){
	   		verif[x][y]=true;
	   		res=verification(x,y-1,player,tabl,verif);
	   		if(res==false) return false;
	   	}

	   	return true;
 
    }

    int suppression(int x,int y,int player,int[][] tabl,boolean[][] verif,int res){

	   	if(x!=0 && tabl[x-1][y]==player && verif[x-1][y]==false){
	   		verif[x][y]=true;
	   		res=suppression(x-1,y,player,tabl,verif,res);
	   	}
	   	if(x!=taille-1 && tabl[x+1][y]==player && verif[x+1][y]==false){
	   		verif[x][y]=true;
	   		res=suppression(x+1,y,player,tabl,verif,res);
	   	}
	   	if(y!=taille-1 && tabl[x][y+1]==player && verif[x][y+1]==false){
	   		verif[x][y]=true;
	   		res=suppression(x,y+1,player,tabl,verif,res);
	   	}
	   	if(y!=0 && tabl[x][y-1]==player && verif[x][y-1]==false){
	   		verif[x][y]=true;
	   		res=suppression(x,y-1,player,tabl,verif,res);
	   	}
	   
	   	tabl[x][y]=0;
	   	return res+1;
	}

	void groupeajt(int x,int y,int player,int[][] tabl,boolean[][] verif,int[][] tablf){

		if(x!=0 && tabl[x-1][y]==player && verif[x-1][y]==false){
	   		verif[x][y]=true;
	   		groupeajt(x-1,y,player,tabl,verif,tablf);
	   	}
	   	if(x!=taille-1 && tabl[x+1][y]==player && verif[x+1][y]==false){
	   		verif[x][y]=true;
	   		groupeajt(x+1,y,player,tabl,verif,tablf);
	   	}
	   	if(y!=taille-1 && tabl[x][y+1]==player && verif[x][y+1]==false){
	   		verif[x][y]=true;
	   		groupeajt(x,y+1,player,tabl,verif,tablf);
	   	}
	   	if(y!=0 && tabl[x][y-1]==player && verif[x][y-1]==false){
	   		verif[x][y]=true;
	   		groupeajt(x,y-1,player,tabl,verif,tablf);
	   	}
	   
	   	if(player==1)tablf[x][y]=2;
	   	else tablf[x][y]=1;
	}

	int verifespacevide(int x,int y,int player, int[][] tabl,boolean[][] verif,int res){

		if(x!=0 && tabl[x-1][y]==player && verif[x-1][y]==false){
			verif[x-1][y]=true;
			res=res+1;
		}
	   	if(x!=taille-1 && tabl[x+1][y]==player && verif[x+1][y]==false){
	   		verif[x+1][y]=true;
			res=res+1;
	   	}
	   	if(y!=taille-1 && tabl[x][y+1]==player && verif[x][y+1]==false){
	   		verif[x][y+1]=true;
			res=res+1;
	   	}
	   	if(y!=0 && tabl[x][y-1]==player && verif[x][y-1]==false){
	   		verif[x][y-1]=true;
			res=res+1;
	   	}

	   	if(x!=0 && tabl[x-1][y]==0 && verif[x-1][y]==false){
	   		verif[x][y]=true;
	   		res=verifespacevide(x-1,y,player,tabl,verif,res);
	   	}
	   	if(x!=taille-1 && tabl[x+1][y]==0 && verif[x+1][y]==false){
	   		verif[x][y]=true;
	   		res=verifespacevide(x+1,y,player,tabl,verif,res);
	   	}
	   	if(y!=taille-1 && tabl[x][y+1]==0 && verif[x][y+1]==false){
	   		verif[x][y]=true;
	   		res=verifespacevide(x,y+1,player,tabl,verif,res);
	   	}
	   	if(y!=0 && tabl[x][y-1]==0 && verif[x][y-1]==false){
	   		verif[x][y]=true;
	   		res=verifespacevide(x,y-1,player,tabl,verif,res);
	   	}

	   	return res;
	}

	void remplir (int x,int y,int player,int[][] tabl, boolean[][] verif){

		if(x!=0 && tabl[x-1][y]==0 && verif[x-1][y]==false){
	   		verif[x][y]=true;
	   		remplir(x-1,y,player,tabl,verif);
	   	}
	   	if(x!=taille-1 && tabl[x+1][y]==0 && verif[x+1][y]==false){
	   		verif[x][y]=true;
	   		remplir(x+1,y,player,tabl,verif);
	   	}
	   	if(y!=taille-1 && tabl[x][y+1]==0 && verif[x][y+1]==false){
	   		verif[x][y]=true;
	   		remplir(x,y+1,player,tabl,verif);
	   	}
	   	if(y!=0 && tabl[x][y-1]==0 && verif[x][y-1]==false){
	   		verif[x][y]=true;
	   		remplir(x,y-1,player,tabl,verif);
	   	}
	   
	   	tabl[x][y]=player;
	}




	void prepatab(int[][] tabl){

		int i = 0;
		int j = 0;

		for(i=0;i<taille;i=i+1){
				for(j=0;j<taille;j=j+1){
					if(tabl[i][j]==3 || tabl[i][j]==4){
						tabl[i][j]=0;
					}
					verif[i][j]=false;
				}
			j=0;
		}
	}

    @Override
	public void mouseClicked(MouseEvent e){}

	@Override
	public void mouseDragged(MouseEvent e){}
	
	@Override
	public void mouseMoved(MouseEvent e){

		int x;
		int y;
		if(taille==9){
			x = e.getX()/cote;
			y = e.getY()/cote;
		}
		else if(taille==13){
			x = (e.getX()-20)/cote;
			y = (e.getY()-20)/cote;
		}
		else {
			x = (e.getX()-35)/cote;
			y = (e.getY()-35)/cote;
		}

		if(x>=taille) return;
		if(y>=taille) return;
		else if(tab[x][y]==0 && player==1 && terminer==false && x<taille && y<taille) {
			
			for(int i=0;i<taille;i=i+1){
				for(int j=0;j<taille;j=j+1){
					if(tab[i][j]==3 || tab[i][j]==4) tab[i][j]=0;
				}
			}
			
			int[][] tabt = new int[taille][taille];

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					tabt[i][j]=tab[i][j];
				}
			}

			tabt[x][y]=1;
			boolean ver;
			prepatab(tabt);
			ver = verification(x,y,player,tabt,verif);
			if(ver==true){
				boolean v1 = false;
				boolean v2 = false;
				boolean v3 = false;
				boolean v4 = false;

				if(x!=0 && tabt[x-1][y]==2){
					prepatab(tabt);
					v1 = verification(x-1,y,2,tabt,verif);
				}
				if(x!=taille-1 && tabt[x+1][y]==2){
					prepatab(tabt);
					v2 = verification(x+1,y,2,tabt,verif);
				}
				if(y!=0 && tabt[x][y-1]==2){
					prepatab(tabt);
					v3 = verification(x,y-1,2,tabt,verif);
				}
				if(y!=taille-1 && tabt[x][y+1]==2){
					prepatab(tabt);
					v4 = verification(x,y+1,2,tabt,verif);
				}

				if(v1==false && v2==false && v3==false && v4==false){
					tab[x][y]=0;
				}
				else {
					player =2;
				}
				
			}
			else {
				player=2;
			}

			if(player==2){
				boolean res;
				int score =0;

				if(x!=taille-1 && tabt[x+1][y]==player){
					prepatab(tabt);
					res = verification(x+1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x+1,y,player,tabt,verif,score);
					}
				}

				if(x!=0 && tabt[x-1][y]==player){
					prepatab(tabt);
					res = verification(x-1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x-1,y,player,tabt,verif,score);
					}
				}
				if(y!=taille-1 && tabt[x][y+1]==player){
					prepatab(tabt);
					res = verification(x,y+1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y+1,player,tabt,verif,score);
					}
				}
				if(y!=0 && tabt[x][y-1]==player){
					prepatab(tabt);
					res = verification(x,y-1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y-1,player,tabt,verif,score);
					}
				}

				Boolean lastv = true;
				if(histo.scroll.getSelectedIndex()>0){
					lastv=false;
					Save test = histo.hi.get(histo.scroll.getSelectedIndex()-1);
					int[][] ttab = test.tab;
					prepatab(ttab);
					for(int i=0;i<taille;i++){
						for(int j=0;j<taille;j++){
							if(test.tab[i][j]!=tabt[i][j]){
								lastv=true;
								break;
							}
						}
						if(lastv==true) break;
					}
					if(lastv==true){
						int nbs =0;
						for(int o=0;o<histo.hi.size();o++){
							lastv=false;
							test=histo.hi.get(o);
							ttab= test.tab;
							prepatab(ttab);
							for(int i=0;i<taille;i++){
								for(int j=0;j<taille;j++){
									if(test.tab[i][j]!=tabt[i][j]){
									lastv=true;
									break;
									}
								}
								if(lastv==true) break;
							}

							if(lastv==false)nbs=nbs+1;
						}
					if(nbs>=3) lastv = false;
					else lastv = true;	
					}
				}

				if(lastv==true){
					tab[x][y]=3;
				}
				else tab[x][y]=0;
			}
			player=1;

		}
		
		else if(tab[x][y]==0 && player==2 && terminer==false && x<taille && y<taille){

			for(int i=0;i<taille;i=i+1){
				for(int j=0;j<taille;j=j+1){
					if(tab[i][j]==3 || tab[i][j]==4) tab[i][j]=0;
				}
			}

			int[][] tabt = new int[taille][taille];

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					tabt[i][j]=tab[i][j];
				}
			}
			
			tabt[x][y]=2;
			boolean ver;
			prepatab(tabt);
			ver = verification(x,y,player,tabt,verif);
			if(ver==true){
				boolean v1 = false;
				boolean v2 = false;
				boolean v3 = false;
				boolean v4 = false;

				if(x!=0 && tabt[x-1][y]==1){
					prepatab(tabt);
					v1 = verification(x-1,y,1,tabt,verif);
				}
				if(x!=taille-1 && tabt[x+1][y]==1){
					prepatab(tabt);
					v2 = verification(x+1,y,1,tabt,verif);
				}
				if(y!=0 && tabt[x][y-1]==1){
					prepatab(tabt);
					v3 = verification(x,y-1,1,tabt,verif);
				}
				if(y!=taille-1 && tabt[x][y+1]==1){
					prepatab(tabt);
					v4 = verification(x,y+1,1,tabt,verif);
				}

				if(v1==false && v2==false && v3==false && v4==false){
					tabt[x][y]=0;
				}
				else {
					player =1;
				}
			}
			else {
				player=1;
			}

			if(player==1){
				boolean res;
				int score =0;

				if(x!=taille-1 && tabt[x+1][y]==player){
					prepatab(tabt);
					res = verification(x+1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x+1,y,player,tabt,verif,score);
					}
				}

				if(x!=0 && tabt[x-1][y]==player){
					prepatab(tabt);
					res = verification(x-1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x-1,y,player,tabt,verif,score);
					}
				}
				if(y!=taille-1 && tabt[x][y+1]==player){
					prepatab(tabt);
					res = verification(x,y+1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y+1,player,tabt,verif,score);
					}
				}
				if(y!=0 && tabt[x][y-1]==player){
					prepatab(tabt);
					res = verification(x,y-1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y-1,player,tabt,verif,score);
					}
				}

				Boolean lastv = true;
				if(histo.scroll.getSelectedIndex()>0){
					lastv=false;
					Save test = histo.hi.get(histo.scroll.getSelectedIndex()-1);
					int[][] ttab = test.tab;
					prepatab(ttab);
					for(int i=0;i<taille;i++){
						for(int j=0;j<taille;j++){
							if(test.tab[i][j]!=tabt[i][j]){
								lastv=true;
								break;
							}
						}
						if(lastv==true) break;
					}
					if(lastv==true){
						int nbs =0;
						for(int o=0;o<histo.hi.size();o++){
							lastv=false;
							test=histo.hi.get(o);
							ttab= test.tab;
							prepatab(ttab);
							for(int i=0;i<taille;i++){
								for(int j=0;j<taille;j++){
									if(test.tab[i][j]!=tabt[i][j]){
									lastv=true;
									break;
									}
								}
								if(lastv==true) break;
							}

							if(lastv==false)nbs=nbs+1;
						}
					if(nbs>=3) lastv = false;
					else lastv = true;	
					}
				}

				if(lastv==true){
					tab[x][y]=4;
				}
				else tab[x][y]=0;
			}
			player=2;

		}
		repaint();
	}
	
	
	@Override
	public void mouseReleased(MouseEvent e){}
	
	@Override
	public void mouseEntered(MouseEvent e){}
	
	@Override
	public void mouseExited(MouseEvent e){}

	@Override
	public void mousePressed(MouseEvent e){

		if(e.getButton()==MouseEvent.BUTTON1 && player==1 && terminer==false) a=1;
		else if(e.getButton()==MouseEvent.BUTTON1 && player==2 && terminer==false) a=2;
		else if(e.getButton()==MouseEvent.BUTTON1 && terminer==true)a=3;
		else if(e.getButton()==MouseEvent.BUTTON3 && terminer==true) a=4;

		int x;
		int y;

		if(taille==9){
			x = e.getX()/cote;
			y = e.getY()/cote;
		}
		else if(taille==13){
			x = (e.getX()-20)/cote;
			y = (e.getY()-20)/cote;
		}
		else {
			x = (e.getX()-35)/cote;
			y = (e.getY()-35)/cote;
		}

		if(x>=taille) return;
		if(y>=taille) return;


		if(a==1 && (tab[x][y]==0 || tab[x][y]==3) && tab[x][y]!=1 && terminer==false && winner==0) {

			int[][] tabt = new int[taille][taille];

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					tabt[i][j]=tab[i][j];
				}
			}

			tabt[x][y]=1;
			boolean ver;
			prepatab(tabt);
			ver = verification(x,y,player,tabt,verif);
			if(ver==true){
				boolean v1 = false;
				boolean v2 = false;
				boolean v3 = false;
				boolean v4 = false;

				if(x!=0 && tabt[x-1][y]==2){
					prepatab(tabt);
					v1 = verification(x-1,y,2,tabt,verif);
				}
				if(x!=taille-1 && tabt[x+1][y]==2){
					prepatab(tabt);
					v2 = verification(x+1,y,2,tabt,verif);
				}
				if(y!=0 && tabt[x][y-1]==2){
					prepatab(tabt);
					v3 = verification(x,y-1,2,tabt,verif);
				}
				if(y!=taille-1 && tabt[x][y+1]==2){
					prepatab(tabt);
					v4 = verification(x,y+1,2,tabt,verif);
				}

				if(v1==false && v2==false && v3==false && v4==false){
					tabt[x][y]=0;
				}
				else {
					player =2;
				}
				
			}
			else {
				player=2;
			}

			if(player==2){
				boolean res;
				int score =0;

				if(x!=taille-1 && tabt[x+1][y]==player){
					prepatab(tabt);
					res = verification(x+1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x+1,y,player,tabt,verif,score);
					}
				}

				if(x!=0 && tabt[x-1][y]==player){
					prepatab(tabt);
					res = verification(x-1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x-1,y,player,tabt,verif,score);
					}
				}
				if(y!=taille-1 && tabt[x][y+1]==player){
					prepatab(tabt);
					res = verification(x,y+1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y+1,player,tabt,verif,score);
					}
				}
				if(y!=0 && tabt[x][y-1]==player){
					prepatab(tabt);
					res = verification(x,y-1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y-1,player,tabt,verif,score);
					}
				}

				Boolean lastv = true;
				if(histo.scroll.getSelectedIndex()>0){
					lastv=false;
					Save test = histo.hi.get(histo.scroll.getSelectedIndex()-1);
					int[][] ttab = test.tab;
					prepatab(ttab);
					for(int i=0;i<taille;i++){
						for(int j=0;j<taille;j++){
							if(test.tab[i][j]!=tabt[i][j]){
								lastv=true;
								break;
							}
						}
						if(lastv==true) break;
					}
					if(lastv==true){
						int nbs =0;
						for(int o=0;o<histo.hi.size();o++){
							lastv=false;
							test=histo.hi.get(o);
							ttab= test.tab;
							prepatab(ttab);
							for(int i=0;i<taille;i++){
								for(int j=0;j<taille;j++){
									if(test.tab[i][j]!=tabt[i][j]){
									lastv=true;
									break;
									}
								}
								if(lastv==true) break;
							}

							if(lastv==false)nbs=nbs+1;
						}
					if(nbs>=3) lastv = false;
					else lastv = true;	
					}
				}

				if(lastv==true){

					sco.scoreu = sco.scoreu + score;
					sco.player = player;
					sco.z = 0;

					if(histo.scroll.getSelectedIndex()+1<histo.hi.size() ){
						histo.hi.removeRange(histo.scroll.getSelectedIndex()+1,histo.hi.size()-1);
					}


					Save joue = new Save(tabt,player,sco.scoreu,sco.scored,tour);
					histo.hi.addElement(joue);
					histo.scroll.setSelectedIndex(histo.scroll.getSelectedIndex()+1);
					tour = tour +1;
					if(sco.type==2)sco.temps = 60;
					sco.repaint();
					repaint();
				}

				else player=1;
			}
		}
		
		if(a==2 && (tab[x][y]==0 || tab[x][y]==4) && tab[x][y]!=2 && terminer==false && winner==0){

			int[][] tabt = new int[taille][taille];

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					tabt[i][j]=tab[i][j];
				}
			}
			
			tabt[x][y]=2;
			boolean ver;
			prepatab(tabt);
			ver = verification(x,y,player,tabt,verif);
			if(ver==true){
				boolean v1 = false;
				boolean v2 = false;
				boolean v3 = false;
				boolean v4 = false;

				if(x!=0 && tabt[x-1][y]==1){
					prepatab(tabt);
					v1 = verification(x-1,y,1,tabt,verif);
				}
				if(x!=taille-1 && tabt[x+1][y]==1){
					prepatab(tabt);
					v2 = verification(x+1,y,1,tabt,verif);
				}
				if(y!=0 && tabt[x][y-1]==1){
					prepatab(tabt);
					v3 = verification(x,y-1,1,tabt,verif);
				}
				if(y!=taille-1 && tabt[x][y+1]==1){
					prepatab(tabt);
					v4 = verification(x,y+1,1,tabt,verif);
				}

				if(v1==false && v2==false && v3==false && v4==false){
					tabt[x][y]=0;
				}
				else {
					player =1;
				}
			}
			else {
				player=1;
			}

			if(player==1){
				boolean res;
				int score =0;

				if(x!=taille-1 && tabt[x+1][y]==player){
					prepatab(tabt);
					res = verification(x+1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x+1,y,player,tabt,verif,score);
					}
				}

				if(x!=0 && tabt[x-1][y]==player){
					prepatab(tabt);
					res = verification(x-1,y,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x-1,y,player,tabt,verif,score);
					}
				}
				if(y!=taille-1 && tabt[x][y+1]==player){
					prepatab(tabt);
					res = verification(x,y+1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y+1,player,tabt,verif,score);
					}
				}
				if(y!=0 && tabt[x][y-1]==player){
					prepatab(tabt);
					res = verification(x,y-1,player,tabt,verif);
					if(res==true){
						prepatab(tabt);
						score = score + suppression(x,y-1,player,tabt,verif,score);
					}
				}

				Boolean lastv = true;
				if(histo.scroll.getSelectedIndex()>0){
					lastv=false;
					Save test = histo.hi.get(histo.scroll.getSelectedIndex()-1);
					int[][] ttab = test.tab;
					prepatab(ttab);
					for(int i=0;i<taille;i++){
						for(int j=0;j<taille;j++){
							if(test.tab[i][j]!=tabt[i][j]){
								lastv=true;
								break;
							}
						}
						if(lastv==true) break;
					}
					if(lastv==true){
						int nbs =0;
						for(int o=0;o<histo.hi.size();o++){
							lastv=false;
							test=histo.hi.get(o);
							ttab= test.tab;
							prepatab(ttab);
							for(int i=0;i<taille;i++){
								for(int j=0;j<taille;j++){
									if(test.tab[i][j]!=tabt[i][j]){
									lastv=true;
									break;
									}
								}
								if(lastv==true) break;
							}

							if(lastv==false)nbs=nbs+1;
						}
					if(nbs>=3) lastv = false;
					else lastv = true;	
					}
				}

				if(lastv==true){
					sco.scored = sco.scored + score;
					sco.player = player;
					sco.z = 0;

					if(histo.scroll.getSelectedIndex()+1<histo.hi.size()){
						histo.hi.removeRange(histo.scroll.getSelectedIndex()+1,histo.hi.size()-1);
					}

					Save joue = new Save(tabt,player,sco.scoreu,sco.scored,tour);
					histo.hi.addElement(joue);
					histo.scroll.setSelectedIndex(histo.scroll.getSelectedIndex()+1);
					tour = tour +1;
					if(sco.type==2)sco.temps = 60;
					sco.repaint();
					repaint();
				}
				else player=2;
			}
		}

		if(a==3 && tab[x][y]!=0 && tabf[x][y]==0 && terminer==true && winner==0){

			prepatab(tab);
			if(tab[x][y]==1) groupeajt(x,y,1,tab,verif,tabf);
			else if(tab[x][y]==2) groupeajt(x,y,2,tab,verif,tabf);
		}

		if(a==4 && tabf[x][y]!=0 && tabf[x][y]!=0 && terminer==true && winner==0){

			prepatab(tabf);
			int nsr=0;
			if(tab[x][y]==1) nsr=suppression(x,y,2,tabf,verif,nsr);
			else if(tab[x][y]==2) nsr=suppression(x,y,1,tabf,verif,nsr);

		}
	}

	 public void actionPerformed(ActionEvent evt) {

    	String composant = evt.getActionCommand();
    	Object source = evt.getSource();

    	if(source==sco.passe){

    		int[][] tabt = new int[taille][taille];

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					tabt[i][j]=tab[i][j];
				}
			}
			prepatab(tabt);


			if(histo.scroll.getSelectedIndex()+1<histo.hi.size()){
					histo.hi.removeRange(histo.scroll.getSelectedIndex()+1,histo.hi.size()-1);
			}

    		Save tp = new Save(tabt,player,sco.scoreu,sco.scored,tour);
    		histo.hi.addElement(tp);
    		histo.scroll.setSelectedIndex(histo.scroll.getSelectedIndex()+1);
    		tour = tour + 1;
    		if(player==1)player = 2;
    		else player=1;
    		sco.player=player;
    		sco.z=sco.z+1;
    		if(sco.type==2)sco.temps = 60;

    		if(sco.z==2){
    			terminer = true;
    			sco.passe.removeActionListener(this);
				sco.aban.removeActionListener(this);
				histo.scroll.removeListSelectionListener(this);
				if(sco.type==2)time.stop();
    		}
    	}
    	
    	if(source==sco.aban){
    		if(sco.player==1)winner=2;
    		else winner=1;
    		terminer = true;
    		abandon = true;
    		sco.passe.removeActionListener(this);
			sco.aban.removeActionListener(this);
			histo.scroll.removeListSelectionListener(this);
			if(sco.type==2)time.stop();
			repaint();
    	}

    	if(source==time){
    		if(sco.temps >0) sco.temps = sco.temps -1;
    		
    		else {
    			if(sco.player==1)winner=2;
    			else winner=1;
    			terminer = true;
    			abandon = true;
    			sco.passe.removeActionListener(this);
				sco.aban.removeActionListener(this);
				histo.scroll.removeListSelectionListener(this);
				time.stop();
				repaint();
    		}
    	}

    	if(source==retour){
    		terminer = false;

    		for(int i=0;i<taille;i++){
    			for(int j=0;j<taille;j++){
    				tabf[i][j]=0;
    			}
    		}

    		sco.passe.addActionListener(this);
			sco.aban.addActionListener(this);
			histo.scroll.addListSelectionListener(this);
			sco.z=0;
			histo.scroll.setSelectedIndex(histo.hi.size()-1);
			if(sco.type==2)time.start();
    	}

    	if(source==valider){

    		
    		sco.passe.removeActionListener(this);
			sco.aban.removeActionListener(this);
			histo.scroll.removeListSelectionListener(this);
			valider.removeActionListener(this);
			retour.removeActionListener(this);

    		int res =0;

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					if(tab[i][j]==1 && tabf[i][j]==2) {
						prepatab(tab);
						res=suppression(i,j,1,tab,verif,res);
						sco.scored = sco.scored + res;
						prepatab(tabf);
						res=suppression(i,j,2,tabf,verif,res);
						res = 0;
					}

					if(tab[i][j]==2 && tabf[i][j]==1) {
						prepatab(tab);
						res=suppression(i,j,2,tab,verif,res);
						sco.scoreu = sco.scoreu +res;
						prepatab(tabf);
						res=suppression(i,j,1,tabf,verif,res);
						res=0;
					}
				}
			}

			repaint();

			int compten = 0;
			int compteb = 0;

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					if(tab[i][j]==0){
						prepatab(tab);
						compten = verifespacevide(i,j,1,tab,verif,compten);
						prepatab(tab);
						compteb = verifespacevide(i,j,2,tab,verif,compteb);

						if(compteb == 0 && compten >0){
							prepatab(tab);
							remplir(i,j,1,tab,verif);
						}
						else if(compten == 0 && compteb >0){
							prepatab(tab);
							remplir(i,j,2,tab,verif);
						}
					}

					compteb=0;
					compten=0;
				}
			}

			repaint();

			for(int i=0;i<taille;i++){
				for(int j=0;j<taille;j++){
					if(tab[i][j]==1) scoruf = scoruf +1;
					if(tab[i][j]==2) scordf = scordf +1;
				}
			}
    		
    		scordf = scordf + sco.bonus;

    		if(scoruf>scordf) winner =1;
    		else if(scoruf<scordf) winner =2;
    		else winner =3;

    		repaint();
    		
    	}
    }

     public void valueChanged(ListSelectionEvent evt) {
     	Save vieux = histo.scroll.getSelectedValue();
     	tab=vieux.tab;
     	player=vieux.player;
     	tour=vieux.tour;
     	sco.player=vieux.player;
     	sco.scoreu=vieux.scoreu;
     	sco.scored=vieux.scored;
     	if(sco.type==2)sco.temps=60;
     	repaint();
     }

}