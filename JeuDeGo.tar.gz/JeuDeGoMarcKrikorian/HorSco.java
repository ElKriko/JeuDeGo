import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;


public class HorSco extends JPanel {

	int type;
	int temps = 60;
	int scoreu = 0;
	int scored = 0;
    double bonus =0;
	JButton aban = new JButton("Abandonner");	
	JButton passe = new JButton("Passer le tour");
	JLabel scoreua = new JLabel();
	JLabel scoreda = new JLabel();
	int player;
	JLabel tour = new JLabel();
	JLabel tempsa = new JLabel();
	int z = 0;


	HorSco(int type){
		this.type=type;
		setSize(430,210);
		setLocation(850,0);
	}

	@Override
    public void paintComponent(Graphics g) {

    	super.paintComponent(g);
    	g.setColor(new Color(77, 255, 28));
    	g.fillRect(0,0,430,210);

    	Font font = new Font("Arial",Font.BOLD,20);
        Font fontd = new Font("Arial",Font.BOLD,18);
    	
    	this.add(scoreua);
    	scoreua.setText("Prisonniers P1 : "+scoreu);
    	scoreua.setFont(fontd);
    	scoreua.setLocation(120,10);
    	
    	this.add(scoreda);
    	scoreda.setText("Prisonniers P2 : "+scored);
    	scoreda.setFont(fontd);
    	scoreda.setLocation(120,40);
    	
    	this.add(tour);
    	tour.setText("Tour : J"+player);
    	tour.setFont(font);
    	tour.setLocation(35,90);
    	
    	this.add(aban);
    	this.add(passe);
    	aban.setLocation(45,160);
    	passe.setLocation(250,160);

    	if(type==2){
            this.add(tempsa);
            tempsa.setText("Temps : "+temps);
            tempsa.setFont(font);
            tempsa.setLocation(250,90);
        }

    	//if(type==3){}
    	
    }

}
