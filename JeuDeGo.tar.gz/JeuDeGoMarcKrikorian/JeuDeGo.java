import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;


public class JeuDeGo {

	public static void main(String[] args){

	JFrame fenetre = new JFrame();
	fenetre.setSize(1280,900);
	fenetre.setLocation(300,10);
	fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	fenetre.setTitle("Jeu de Go");
	fenetre.setLayout(null);
	
	Menu m = new Menu(fenetre);
	fenetre.setContentPane(m);
	fenetre.setVisible(true);
	}
}