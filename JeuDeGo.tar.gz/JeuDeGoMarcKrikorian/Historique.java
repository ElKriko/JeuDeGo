import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;


public class Historique extends JPanel{

	JLabel histo = new JLabel("Historique");
	DefaultListModel<Save> hi;
	JList<Save> scroll;
	JScrollPane barre;

	Historique(){
		setLocation(850,210);
		setSize(430,690);
		hi = new DefaultListModel<Save>();
		scroll = new JList<Save>(hi);
		barre = new JScrollPane(scroll);
	}

	@Override
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	g.setColor(new Color(239,239,239));
    	g.fillRect(0,0,430,690);

    	Font font = new Font("Arial",Font.BOLD,20);

    	this.add(histo);
    	histo.setFont(font);
    	histo.setLocation(150,15);

    	this.add(barre);
    	barre.setLocation(40,50);
    	barre.setPreferredSize(new Dimension(350,590));
    	barre.setMaximumSize(new Dimension(350,590));


    }

   
}
