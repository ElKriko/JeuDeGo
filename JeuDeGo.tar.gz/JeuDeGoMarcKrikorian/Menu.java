import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;

public class Menu extends JPanel implements ActionListener{

	int time;
	int handi = 0;
	int taille;
	
	JButton jouer = new JButton("Jouer");
	
	JLabel titre = new JLabel("Jeu de Go");
	
	JFrame fenetre = null;

	JLabel tailleaff = new JLabel("Taille du terrain");
	ButtonGroup taillet = new ButtonGroup();
	JRadioButton nxn = new JRadioButton("9x9");
	JRadioButton txt = new JRadioButton("13x13");
	JRadioButton dnxdn = new JRadioButton("19x19");

	JLabel timeaff = new JLabel("Temps");
	ButtonGroup temps = new ButtonGroup();
	JRadioButton past = new JRadioButton("Pas de temps");
	JRadioButton tptour = new JRadioButton("Une minute par tour");

	JLabel handica = new JLabel("Handicap");
	JLabel handiaff = new JLabel();
	JLabel handiatt = new JLabel("Le handicap sera ramené à 5 si il est supérieur à 5 pour un terrain autre que le 19x19");
	JButton mhandi = new JButton("-");
	JButton phandi = new JButton("+"); 

	Menu(JFrame fenetre){

		this.fenetre=fenetre;
		jouer.addActionListener(this);
		setSize(1280,900);
		setLocation(0,0);
		taillet.add(nxn);
		taillet.add(txt);
		taillet.add(dnxdn);
		nxn.setSelected(true);
		temps.add(past);
		temps.add(tptour);
		past.setSelected(true);
		mhandi.addActionListener(this);
		phandi.addActionListener(this);
	}

	@Override
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);

    	Font font = new Font("Arial",Font.BOLD,60);
    	
    	g.setColor(new Color(77, 255, 28));
    	g.fillRect(0,0,1280,150);
    	g.fillRect(0,720,1280,150);
    	g.fillRect(0,150,320,600);
    	g.fillRect(960,150,320,600);

    	this.add(jouer);
    	jouer.setLocation(490,575);
    	jouer.setSize(300,100);
    	jouer.setFont(new Font("Arial",Font.BOLD,45));

    	this.add(titre);
    	titre.setFont(font);
    	titre.setLocation(485,35);

    	this.add(tailleaff);
    	tailleaff.setLocation(350,250);
    	tailleaff.setFont(new Font("Arial",Font.BOLD,20));

    	this.add(nxn);
    	nxn.setLocation(600,250);
    	this.add(txt);
    	txt.setLocation(700,250);
    	this.add(dnxdn);
    	dnxdn.setLocation(800,250);

    	this.add(timeaff);
    	timeaff.setLocation(350,350);
    	timeaff.setFont(new Font("Arial",Font.BOLD,20));

    	this.add(past);
    	past.setLocation(450,350);
    	this.add(tptour);
    	tptour.setLocation(580,350);

    	this.add(handica);
    	handica.setLocation(350,450);
    	handica.setFont(new Font("Arial",Font.BOLD,20));

    	this.add(mhandi);
    	mhandi.setLocation(500,450);
    	this.add(phandi);
    	phandi.setLocation(600,450);
    	this.add(handiaff);
    	handiaff.setText(handi+"");
    	handiaff.setLocation(565,455);
    	this.add(handiatt);
    	handiatt.setLocation(350,505);



    }

    public void actionPerformed(ActionEvent evt) {

    	String composant = evt.getActionCommand();
    	Object source = evt.getSource();

    	if(source==mhandi){
    		handi=handi-1;
    		if(handi<0)handi=0;
    	}

    	if(source==phandi){
    		handi=handi+1;
    		if(handi>9)handi=9;
    	}

    	if(source==jouer){

    		if(nxn.isSelected())taille=9;
    		else if(txt.isSelected())taille=13;
    		else taille=19;

    		if(past.isSelected())time=1;
    		else if(tptour.isSelected())time=2;
    		else time=3;

    		if(handi>5 && taille!=19)handi=5;

    		Historique h = new Historique();
			HorSco s = new HorSco(time);
			Plateau p = new Plateau(taille,s,handi,h);
			Jeu j = new Jeu(fenetre,s,p,h);
			fenetre.remove(this);
			fenetre.setContentPane(j);
    	}
    }


}
