import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;

public class Jeu extends JPanel implements ActionListener{

	Plateau p;
	JFrame fenetre;	

	Jeu(JFrame fenetre,HorSco s,Plateau p,Historique h){
		this.fenetre = fenetre;
		this.p = p;
		this.add(s);
		this.add(p);
		this.add(h);
		setLayout(null);
		p.ok.addActionListener(this);
	}

	public void actionPerformed(ActionEvent evt) {

    	String composant = evt.getActionCommand();
    	Object source = evt.getSource();

    	if(source==p.ok){

    		Menu m = new Menu(fenetre);
    		fenetre.remove(this);
    		fenetre.setContentPane(m);

    	}
    }
}
