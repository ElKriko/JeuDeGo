import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;

public class Save {

	int[][] tab = null;
	int player;
	int scoreu;
	int scored;
	int tour;

	Save(int[][]tab,int player,int scoreu, int scored,int tour){
		this.tab=tab;
		this.player=player;
		this.scoreu=scoreu;
		this.scored=scored;
		this.tour = tour;
	}
}